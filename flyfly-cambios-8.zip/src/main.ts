import '@cesium/engine/Source/Widget/CesiumWidget.css';
import '@fontsource-variable/outfit';
import './style.css';
import { CITY_ALTITUDE, Controls, Craft } from './flight';
import { HOME, IntroScene } from './intro';
import { geoidHeight, loadGeoid } from './geoid';
import { hydrateIcons, icon, IconName } from './icons';
import { adsEnabled, manageConsent, showAd } from './ads';
import { AdvertiserLayer, loadAdvertisers } from './advertisers';
import { track } from './analytics';
import { CITY_ID, loadEdition, loadEditionPois } from './edition';
import { cityTags, FinderResult, loadRanking, RankingCity, searchPlaces, warmFinder } from './finder';
import { bearing, distance, fetchImageCredit, fetchSummary, formatDistance, FoundVisibility, loadCityPois, loadSponsors, Poi, PoiLayer, wikiUrl } from './pois';
import { createWorld, geocode, GeoResult, groundHeight, waitForPreload, initialQuality, Quality, setQuality, World } from './world';
// Sonido desactivado (para reactivarlo, descomenta las líneas marcadas con "Sonido").
// import { EngineSound } from './sound'; // Sonido
import { Matrix4 } from '@cesium/engine';

const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
hydrateIcons();

const [world] = await Promise.all([createWorld($('world')), loadGeoid()]);
const { viewer } = world;
const ufo = new Craft(viewer);
const pois = new PoiLayer(viewer, $('markers'));
const ads = new AdvertiserLayer(viewer, $('markers'));
// const sound = new EngineSound(); // Sonido
await ufo.load('models/ufo.glb');
// Menú principal: la Tierra girando y el ovni acercándose por la derecha.
viewer.camera.setView({ destination: HOME });
const intro = new IntroScene(viewer, ufo);
intro.showIdle();
let quality: Quality = initialQuality();
setQuality(world, quality);

$('mode-note').textContent = world.error
  ? `No se pudo cargar la ciudad en 3D (${world.error}). Revisa el token de Cesium ion. Se muestra la ortofoto plana.`
  : world.mode === 'free'
    ? 'Modo plano (ortofoto). Añade un token de Cesium ion para ver las ciudades en 3D.'
    : '';

let flying = false;
let paused = true;
let currentCity: GeoResult | undefined;

// Edición de ciudad (ayuntamiento) si se compiló con VITE_CIUDAD; si no, la general.
const edition = await loadEdition().catch((e) => {
  $('mode-note').textContent = String(e.message ?? e);
  return undefined;
});
const editionCity: GeoResult | undefined = edition && { name: edition.name, detail: edition.detail ?? '', lat: edition.lat, lng: edition.lng };
if (CITY_ID) document.body.classList.add('edition-city');
let lastPos: { lat: number; lng: number } | undefined;

// Estadísticas por ciudad (en el navegador): primer descubrimiento, finalización y distancia recorrida.
interface CityStats { first?: number; completed?: number; km?: number }
const STATS_KEY = 'flyfly:cities';
const cityKey = (c: GeoResult) => `${c.name}|${c.lat.toFixed(2)}|${c.lng.toFixed(2)}`;
function loadStats(): Record<string, CityStats> {
  try { return JSON.parse(localStorage.getItem(STATS_KEY) ?? '{}'); } catch { return {}; }
}
function cityStats(): CityStats {
  return currentCity ? loadStats()[cityKey(currentCity)] ?? {} : {};
}
function saveCityStats(patch: CityStats) {
  if (!currentCity) return;
  const all = loadStats();
  all[cityKey(currentCity)] = { ...all[cityKey(currentCity)], ...patch };
  try { localStorage.setItem(STATS_KEY, JSON.stringify(all)); } catch { /* sin almacenamiento */ }
}
const timeout = <T>(ms: number, value: T) => new Promise<T>((r) => setTimeout(() => r(value), ms));

// ---------- Avisos ----------
let toastTimer = 0;
function toast(opts: { title: string; label?: string; image?: string; iconName?: IconName }) {
  const t = $('toast');
  t.innerHTML = '';
  t.className = opts.label ? 'toast' : 'toast is-info';
  if (opts.image) {
    const img = document.createElement('img');
    img.src = opts.image;
    img.alt = '';
    t.append(img);
  } else if (opts.iconName) {
    const i = document.createElement('span');
    i.className = 'toast-icon';
    i.innerHTML = icon(opts.iconName);
    t.append(i);
  }
  const text = document.createElement('div');
  if (opts.label) {
    const small = document.createElement('small');
    small.textContent = opts.label;
    text.append(small);
  }
  const b = document.createElement('b');
  b.textContent = opts.title;
  text.append(b);
  t.append(text);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => (t.hidden = true), 3200);
}

let areaTimer = 0;
function showAreaTitle(name: string, sub: string) {
  const el = $('area-title');
  $('area-name').textContent = name;
  $('area-sub').textContent = sub;
  el.hidden = true;
  void el.offsetWidth; // reinicia la animación
  el.hidden = false;
  clearTimeout(areaTimer);
  areaTimer = window.setTimeout(() => (el.hidden = true), 3300);
}

// ---------- Búsqueda de ciudad ----------
const searchInput = $<HTMLInputElement>('search-input');
const searchBtn = $<HTMLButtonElement>('search-btn');
const RECENT_KEY = 'flyfly:recent';

function setStatus(text: string, error = false) {
  const s = $('search-status');
  s.textContent = text;
  s.classList.toggle('is-error', error);
}

function loadRecent(): GeoResult[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) ?? '[]');
  } catch {
    return [];
  }
}

function saveRecent(place: GeoResult) {
  const list = [place, ...loadRecent().filter((p) => p.name !== place.name || p.detail !== place.detail)].slice(0, 4);
  try { localStorage.setItem(RECENT_KEY, JSON.stringify(list)); } catch { /* sin almacenamiento */ }
}

function renderRecent() {
  const list = loadRecent();
  const box = $('recent-list');
  box.innerHTML = '';
  $('recent').hidden = !list.length;
  for (const place of list) {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = `${icon('recent')}<span></span>`;
    b.querySelector('span')!.textContent = place.name;
    b.title = place.detail;
    b.onclick = () => startFlight(place);
    box.append(b);
  }
}

// Portada de la edición de ciudad: sin buscador de ciudades ni anuncios, con su título y su logotipo.
if (edition && editionCity) {
  document.title = `${edition.title ?? edition.name} · FlyFly`;
  $('intro-title').textContent = edition.title ?? `Sobrevuela ${edition.name}`;
  $('intro-lead').textContent = edition.subtitle ?? `Pilota un ovni sobre ${edition.name} en 3D y descubre sus lugares más especiales.`;
  if (edition.logo) { const logo = $<HTMLImageElement>('city-logo'); logo.src = edition.logo; logo.hidden = false; }
  $('search').hidden = $('results').hidden = $('recent').hidden = $('advertise-note').hidden = true;
  const start = $<HTMLButtonElement>('start-btn');
  start.textContent = edition.start ?? 'Despegar';
  start.hidden = false;
  start.onclick = () => (flying ? ($('intro').hidden = true, paused = false) : startFlight(editionCity));
  start.focus();
} else {
  searchInput.disabled = searchBtn.disabled = false;
  setStatus('');
  renderRecent();
  searchInput.focus();
}

function openSearch() {
  closePanels();
  paused = true;
  $('results').innerHTML = '';
  setStatus('');
  renderRecent();
  $('intro-close').hidden = !flying;
  $('intro').hidden = false;
  if (edition) {
    $('start-btn').textContent = flying ? 'Seguir volando' : edition.start ?? 'Despegar';
    return;
  }
  searchInput.select();
  searchInput.focus();
}
$('city-btn').onclick = openSearch;

/** Vuelve al menú principal: deja la ciudad y muestra el planeta con el buscador. */
function goHome() {
  stopAutopilot();
  closePanels();
  $('victory').hidden = true;
  flying = false;
  paused = true;
  currentCity = undefined; // cancela un despegue en curso
  launchStatus('');
  document.body.classList.remove('flying');
  pois.clear();
  ads.clear();
  ufo.hide();
  viewer.camera.lookAtTransform(Matrix4.IDENTITY);
  viewer.camera.flyTo({ destination: HOME, duration: 2 });
  intro.showIdle(2.2);
  searchInput.value = '';
  $('results').innerHTML = '';
  setStatus('');
  renderRecent();
  $('intro-close').hidden = true;
  $('intro').hidden = false;
  if (edition) $('start-btn').textContent = edition.start ?? 'Despegar';
}
$('home-btn').onclick = goHome;
$('intro-close').onclick = () => {
  $('intro').hidden = true;
  paused = false;
};

$('search').addEventListener('submit', async (e) => {
  e.preventDefault();
  const query = searchInput.value.trim();
  const list = $('results');
  list.innerHTML = '';
  if (!query) {
    setStatus('Escribe el nombre de una ciudad o lugar.', true);
    searchInput.focus();
    return;
  }
  setStatus('Buscando…');
  searchBtn.disabled = true;
  let hits: GeoResult[] = [];
  try {
    hits = await geocode(world, query);
  } catch {
    setStatus('La búsqueda no está disponible ahora mismo. Inténtalo de nuevo.', true);
    return;
  } finally {
    searchBtn.disabled = false;
  }
  if (!hits.length) return setStatus('No encontré ese lugar. Prueba con otro nombre.', true);
  if (hits.length === 1) return startFlight(hits[0]);
  setStatus('Hay varios lugares con ese nombre. Elige uno:');
  for (const hit of hits) {
    const li = document.createElement('li');
    li.innerHTML = `<button type="button">${icon('pin')}<span><b></b><small></small></span></button>`;
    li.querySelector('b')!.textContent = hit.name;
    li.querySelector('small')!.textContent = hit.detail;
    li.querySelector('button')!.onclick = () => startFlight(hit);
    list.append(li);
  }
});

let launching = false;
async function startFlight(place: GeoResult) {
  if (launching) return;
  launching = true;
  try {
    await launch(place);
  } finally {
    launching = false;
  }
}

async function launch(place: GeoResult) {
  stopAutopilot();
  if (!edition) saveRecent(place);
  currentCity = place;
  const advertise = $<HTMLAnchorElement>('advertise-btn');
  advertise.hidden = !!edition;
  advertise.href = `anunciate.html?${new URLSearchParams({ ciudad: place.name, lat: place.lat.toFixed(5), lng: place.lng.toFixed(5) })}`;
  lastPos = undefined;
  track('ciudad', { ciudad: place.name, edicion: CITY_ID || 'general' });
  // sound.start(); // Sonido
  $('intro').hidden = true;
  $('results').innerHTML = '';
  setStatus('');
  const n = await flyTo(place);
  if (currentCity !== place) return;
  flying = true;
  paused = false;
  document.body.classList.add('flying');
  const { total } = pois.progress();
  showAreaTitle(place.name, [
    total ? `${total} lugares escondidos por descubrir` : 'No hay lugares registrados en esta zona',
    n ? `${n} ${n === 1 ? 'negocio' : 'negocios'} en el mapa` : '',
  ].filter(Boolean).join(' · '));
  showHelpOnce();
}

// ---------- Despegue: animación del ovni desde el menú hasta la ciudad ----------
function launchStatus(text: string) {
  $('launch-text').textContent = text;
  $('launch').hidden = !text;
}

/** Espera a que carguen las teselas visibles (como mucho `maxMs`), informando del avance de 0 a 1. */
function loadTiles(w: World, onProgress: (f: number) => void = () => {}, maxMs = 15000): Promise<void> {
  return new Promise((resolve) => {
    let maxPending = 1;
    const update = (pending: number, processing: number) => {
      const left = pending + processing;
      maxPending = Math.max(maxPending, left);
      onProgress(1 - left / maxPending);
    };
    const finish = () => { clearTimeout(timer); removeProgress(); removeDone(); resolve(); };
    const timer = setTimeout(finish, maxMs);
    const removeProgress = w.tileset
      ? w.tileset.loadProgress.addEventListener(update)
      : w.viewer.scene.globe.tileLoadProgressEvent.addEventListener((n: number) => update(n, 0));
    const removeDone = w.tileset
      ? w.tileset.allTilesLoaded.addEventListener(finish)
      : w.viewer.scene.globe.tileLoadProgressEvent.addEventListener((n: number) => n === 0 && finish());
  });
}

/**
 * Lleva el ovni a la ciudad: mientras se cargan los lugares arranca motores en el menú, después vuela
 * con la cámara hasta su posición sobre la ciudad (Cesium precarga las teselas del destino durante el
 * vuelo) y al llegar espera, como mucho unos segundos, a que terminen de cargar los edificios.
 */
async function flyTo(place: GeoResult): Promise<number> {
  paused = true;
  closePanels();
  pois.clear();
  ads.clear();
  document.body.classList.remove('flying');
  $('city-name').textContent = $('drawer-city').textContent = $('finder-city').textContent = place.name;
  // El buscador empieza vacío en cada ciudad.
  $('finder-results').replaceChildren();
  $('finder-status').textContent = '';
  $<HTMLInputElement>('finder-input').value = '';
  $<HTMLSelectElement>('finder-tags').innerHTML = '<option value="">Todas</option>';
  tagsCity = undefined;
  launchStatus('Arrancando motores…');
  intro.warmup();

  // Lugares, anunciantes y altura del suelo a la vez; como mínimo 1,8 s de arranque y como máximo 9 s de espera.
  const places = edition ? loadEditionPois(edition) : loadCityPois(place.lat, place.lng);
  const sponsors = edition ? Promise.resolve([]) : loadSponsors(place.lat, place.lng);
  const advertisers = edition ? Promise.resolve([]) : loadAdvertisers(place.lat, place.lng);
  const ground = Promise.race([groundHeight(world, place.lat, place.lng), timeout(8000, 0)]);
  const city = place;
  const addPlaces = (list: Poi[]) => { if (currentCity === city) pois.add(list); };
  const data = Promise.all([places.then(addPlaces), sponsors.then(addPlaces)]).catch(() => {
    if (currentCity === city) toast({ title: 'No se pudieron cargar los lugares de interés', iconName: 'warning' });
  });
  await Promise.all([timeout(1800, 0), Promise.race([Promise.all([data, ground]), timeout(9000, 0)])]);
  if (currentCity !== city) return 0;

  ufo.teleport(place.lat, place.lng, await Promise.race([ground, timeout(0, 0)]), CITY_ALTITUDE);
  ufo.heading = 0;
  // La ciudad se descarga antes de salir: el ovni sigue arrancando motores en el menú mientras tanto.
  intro.prepare(ufo.lat, ufo.lng, ufo.height, ufo.chaseView);
  launchStatus(`Cargando ${place.name}…`);
  await waitForPreload(world, (f) => currentCity === city && launchStatus(`Cargando ${place.name} ${Math.round(f * 100)} %`));
  if (currentCity !== city) return 0;
  launchStatus(`Rumbo a ${place.name}`);
  await intro.launch();
  if (currentCity !== city) return 0;
  intro.stop();
  ufo.snapCamera();
  updateHud();
  const adList = await advertisers.catch(() => []);
  // Ya se puede jugar (la ciudad se cargó antes de salir); los anunciantes se colocan sobre el terreno.
  launchStatus('');
  void ads.add(adList, ufo.excluded).then(() => currentCity !== city && ads.clear());
  return adList.length;
}

// ---------- Viajar a un lugar (teletransporte) ----------
/** Lleva el ovni junto a un lugar con una animación de 2 a 4 s mientras se cargan las teselas. */
async function travelTo(poi: Poi) {
  closePanels();
  paused = true;
  const warp = $('warp');
  $('warp-name').textContent = poi.name;
  warp.classList.remove('is-leaving');
  warp.hidden = false;
  await timeout(450, 0);
  // Aparece 150 m al sur del lugar, mirando hacia él.
  const lat = poi.lat - 150 / 111320, lng = poi.lng;
  ufo.teleport(lat, lng, ufo.ground);
  ufo.heading = 0;
  ufo.render(0);
  const [ground] = await Promise.all([
    Promise.race([groundHeight(world, lat, lng), timeout(4000, ufo.ground)]),
    timeout(1400, 0),
  ]);
  ufo.teleport(lat, lng, ground);
  ufo.heading = 0;
  ufo.render(0);
  lastPos = { lat, lng };
  await loadTiles(world, () => {}, 3500);
  warp.classList.add('is-leaving');
  await timeout(350, 0);
  warp.hidden = true;
  paused = false;
}

// ---------- Ficha del lugar ----------
let openPoi: Poi | undefined;
let sheetFromDiscovery = false;

function setTag(el: HTMLElement, kind: 'found' | 'sponsor' | 'mystery') {
  const label = { found: 'Descubierto', sponsor: 'Patrocinado', mystery: 'Por descubrir' }[kind];
  const iconName: IconName = { found: 'check', sponsor: 'star', mystery: 'question' }[kind] as IconName;
  el.className = `tag tag-${kind}`;
  el.innerHTML = `${icon(iconName)}<span></span>`;
  el.querySelector('span')!.textContent = label;
}

async function openSheet(poi: Poi, fromDiscovery = false) {
  openPoi = poi;
  if (poi.id.startsWith('ad_')) track('anuncio-ficha', { anuncio: poi.id.slice(3) });
  sheetFromDiscovery = fromDiscovery;
  closeDrawer();
  closeFinder();
  closeRanking();
  closePopovers();
  const img = $<HTMLImageElement>('sheet-img');
  $('sheet').classList.toggle('no-media', !poi.image);
  img.hidden = !poi.image;
  if (poi.image) img.src = poi.image;
  img.alt = poi.name;
  setTag($('sheet-status'), poi.sponsor ? 'sponsor' : pois.isDiscovered(poi) ? 'found' : 'mystery');
  $('sheet-dist').textContent = `A ${formatDistance(distance(ufo, poi))}`;
  $('sheet-title').textContent = poi.name;
  const desc = poi.description ? poi.description[0].toUpperCase() + poi.description.slice(1) : '';
  $('sheet-desc').textContent = desc;
  $('sheet-desc').hidden = !desc;
  $('sheet-text').textContent = poi.body ?? '';
  const gallery = $('sheet-gallery');
  gallery.innerHTML = '';
  gallery.hidden = (poi.gallery?.length ?? 0) < 2;
  for (const src of poi.gallery ?? []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = '<img alt="" loading="lazy" />';
    b.querySelector('img')!.src = src;
    b.onclick = () => { img.src = src; };
    gallery.append(b);
  }
  const link = $<HTMLAnchorElement>('sheet-link');
  link.hidden = !poi.wikiTitle && !poi.url;
  link.href = poi.url ?? (poi.wikiTitle ? wikiUrl(poi.wikiTitle) : '#');
  const cta = $<HTMLAnchorElement>('sheet-cta');
  cta.hidden = !poi.sponsor?.link;
  if (poi.sponsor?.link) {
    cta.href = poi.sponsor.link;
    cta.textContent = poi.sponsor.cta ?? 'Visitar web';
  }
  const maps = $<HTMLAnchorElement>('sheet-maps');
  maps.hidden = !poi.sponsor?.maps;
  if (poi.sponsor?.maps) maps.href = poi.sponsor.maps;
  const travelBtn = $('sheet-travel');
  travelBtn.hidden = !(pois.isDiscovered(poi) || poi.id.startsWith('ad_')) || distance(ufo, poi) < 300;
  travelBtn.onclick = () => travelTo(poi);
  const credit = $('sheet-credit');
  credit.textContent = '';
  $('sheet').hidden = false;
  if (adsEnabled && !poi.sponsor) showAd($('sheet-ad'));
  else $('sheet-ad').hidden = true;

  const [summary, photo] = await Promise.all([
    poi.wikiTitle ? fetchSummary(poi.wikiTitle).catch(() => undefined) : undefined,
    poi.image ? fetchImageCredit(poi.image).catch(() => undefined) : undefined,
  ]);
  if (openPoi !== poi) return;
  $('sheet-text').textContent = summary?.extract ?? poi.body ?? '';
  if (summary?.url) link.href = summary.url;
  if (!poi.image && summary?.image) {
    img.src = summary.image;
    img.hidden = false;
    $('sheet').classList.remove('no-media');
  }
  // Atribución obligatoria: autor y licencia de la foto, y licencia del texto.
  credit.textContent = '';
  if (photo) {
    credit.append('Foto: ');
    const a = document.createElement('a');
    a.href = photo.url;
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = photo.artist;
    credit.append(a, photo.license ? ` (${photo.license}). ` : '. ');
  }
  if (poi.wikiTitle) credit.append('Texto: Wikipedia (CC BY-SA 4.0).');
  if (poi.id.startsWith('ad_')) credit.append(`Contenido publicitario proporcionado por ${poi.name}.`);
}

function closeSheet() {
  openPoi = undefined;
  $('sheet').hidden = true;
}
$('sheet-close').onclick = closeSheet;

ads.onSelect = (poi) => openSheet(poi);
// Estadísticas anónimas para los anunciantes: veces que se ha visto su anuncio, se ha abierto su ficha y se ha pulsado su botón.
ads.onSeen = (ad) => track('anuncio-visto', { anuncio: ad.id, tipo: ad.type });
$('sheet-maps').addEventListener('click', () => {
  if (openPoi?.id.startsWith('ad_')) track('anuncio-mapa', { anuncio: openPoi.id.slice(3) });
});
$('sheet-cta').addEventListener('click', () => {
  if (openPoi?.id.startsWith('ad_')) track('anuncio-clic', { anuncio: openPoi.id.slice(3) });
});
pois.onSelect = (poi) => {
  if (pois.isDiscovered(poi) || poi.sponsor) openSheet(poi);
  else toast({ title: 'Acércate para descubrir este lugar', iconName: 'question' });
};

// ---------- Lugares descubiertos ----------
let gridCount = -1;

function renderDrawer() {
  const { discovered, total } = pois.progress();
  $('drawer-found').textContent = String(discovered);
  $('drawer-total').textContent = String(total);
  $('drawer-bar').style.width = total ? `${(discovered / total) * 100}%` : '0';

  const hints = pois.hints(ufo.lat, ufo.lng);
  $('drawer-hints-section').hidden = !hints.length;
  const list = $('drawer-hints');
  list.innerHTML = '';
  for (const { poi, dist } of hints) {
    const rel = bearing(ufo, poi) - (ufo.heading * 180) / Math.PI;
    const li = document.createElement('li');
    li.innerHTML = `<span class="compass-arrow" style="transform: rotate(${(rel + 45).toFixed(0)}deg)">${icon('nav')}</span>${formatDistance(dist)}`;
    list.append(li);
  }

  // La cuadrícula solo se rehace cuando cambia el número de descubiertos (evita recargar fotos).
  const found = [...pois.pois.values()].filter((p) => pois.isDiscovered(p) && !p.sponsor);
  $('drawer-empty').hidden = found.length > 0;
  if (found.length === gridCount) return;
  gridCount = found.length;
  const grid = $('drawer-grid');
  grid.innerHTML = '';
  for (const poi of found) {
    // Al pulsar se abre la ficha, que tiene el botón "Viajar aquí".
    const tile = document.createElement('button');
    tile.type = 'button';
    tile.className = 'place';
    tile.innerHTML = '<img alt="" loading="lazy" /><span></span>';
    if (poi.thumb) tile.querySelector('img')!.src = poi.thumb;
    tile.querySelector('span')!.textContent = poi.name;
    tile.onclick = () => openSheet(poi);
    grid.append(tile);
  }
}

function closeDrawer() {
  $('drawer').hidden = true;
}
function toggleDrawer() {
  const drawer = $('drawer');
  if (!drawer.hidden) return closeDrawer();
  closePopovers();
  closeSheet();
  closeFinder();
  closeRanking();
  gridCount = -1;
  renderDrawer();
  drawer.hidden = false;
}
$('menu-btn').onclick = toggleDrawer;
$('drawer-close').onclick = closeDrawer;

// ---------- Buscador de la ciudad ----------
function closeFinder() {
  $('finder').hidden = true;
}
function openFinder() {
  if (!$('finder').hidden) return closeFinder();
  closePopovers();
  closeSheet();
  closeDrawer();
  closeRanking();
  $('finder').hidden = false;
  if (currentCity) {
    warmFinder(currentCity, !edition);
    void fillTags(currentCity);
    // Al abrir, la lista completa (anunciantes primero, del que más paga al que menos).
    if (!$('finder-results').childElementCount) void runFinder();
  }
  const input = $<HTMLInputElement>('finder-input');
  input.focus();
  input.select();
}
$('finder-btn').onclick = openFinder;
$('finder-close').onclick = closeFinder;
$('finder-input').addEventListener('keydown', (e) => { if (e.key === 'Escape') closeFinder(); });
$('finder-form').addEventListener('submit', (e) => {
  e.preventDefault();
  void runFinder();
});
$('finder-tags').addEventListener('change', () => void runFinder());

/** Desplegable de categorías: las etiquetas de los anunciantes de la ciudad. */
let tagsCity: GeoResult | undefined;
async function fillTags(city: GeoResult) {
  const select = $<HTMLSelectElement>('finder-tags');
  $('finder-filter').hidden = !!edition;
  if (edition || tagsCity === city) return;
  tagsCity = city;
  const tags = await cityTags(city);
  if (currentCity !== city) return;
  select.innerHTML = '<option value="">Todas</option>';
  for (const { tag, count } of tags) select.append(new Option(`${tag} (${count})`, tag));
}

let finderRun = 0;
async function runFinder() {
  const city = currentCity;
  if (!city) return;
  const query = $<HTMLInputElement>('finder-input').value.trim();
  const tag = $<HTMLSelectElement>('finder-tags').value;
  const run = ++finderRun;
  if (query || tag) track('busqueda', { texto: (query || tag).toLowerCase().slice(0, 40), ciudad: city.name });
  // En la edición de ciudad se buscan sus lugares (en la general, los de Wikipedia se descubren volando).
  const own = edition ? [...pois.pois.values()].filter((p) => p.id.startsWith('c_')) : [];
  const results = await searchPlaces(query, city, ufo, { ads: !edition, places: own, tag });
  if (run !== finderRun) return;
  const list = $('finder-results');
  list.replaceChildren(...results.map(renderResult));
  const what = edition ? ['lugar', 'lugares'] : ['negocio', 'negocios'];
  $('finder-status').textContent = results.length
    ? `${results.length} ${results.length === 1 ? what[0] : what[1]}`
    : query || tag
      ? `No encontré «${query || tag}» en ${city.name}.`
      : edition ? '' : `Todavía no hay negocios anunciados en ${city.name}. ¡Sé el primero desde «Anúnciate»!`;
}

// ---------- Ranking de países y ciudades con más anunciantes ----------
function closeRanking() {
  $('ranking').hidden = true;
}
async function openRanking() {
  if (!$('ranking').hidden) return closeRanking();
  closePopovers();
  closeSheet();
  closeDrawer();
  closeFinder();
  $('ranking').hidden = false;
  const countries = await loadRanking();
  const cityRow = (c: RankingCity, rank: number) => {
    const li = document.createElement('li');
    li.innerHTML = `<button type="button" class="ranking-row"><span class="rank"></span><span class="ranking-name"><b></b><small></small></span><span class="ranking-count"></span>${icon('travel')}</button>`;
    li.querySelector('.rank')!.textContent = String(rank);
    li.querySelector('b')!.textContent = c.name;
    li.querySelector('small')!.textContent = c.country;
    li.querySelector('.ranking-count')!.textContent = `${c.count} ${c.count === 1 ? 'anunciante' : 'anunciantes'}`;
    li.querySelector('button')!.onclick = () => {
      closeRanking();
      track('ranking-viaje', { ciudad: c.name });
      void startFlight({ name: c.name, detail: c.country, lat: c.lat, lng: c.lng });
    };
    return li;
  };
  const all = countries.flatMap((c) => c.cities).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, 'es'));
  $('ranking-cities').replaceChildren(...all.slice(0, 10).map((c, i) => cityRow(c, i + 1)));
  $('ranking-countries').replaceChildren(...countries.map((country, i) => {
    const d = document.createElement('details');
    d.innerHTML = `<summary><span class="rank"></span><b></b><span class="ranking-count"></span></summary><ol class="ranking-list"></ol>`;
    d.querySelector('.rank')!.textContent = String(i + 1);
    d.querySelector('b')!.textContent = country.name;
    d.querySelector('.ranking-count')!.textContent = `${country.count} en ${country.cities.length} ${country.cities.length === 1 ? 'ciudad' : 'ciudades'}`;
    d.querySelector('ol')!.replaceChildren(...country.cities.map((c, j) => cityRow(c, j + 1)));
    if (i === 0) d.open = true;
    return d;
  }));
  $('ranking-empty').hidden = all.length > 0;
}
$('ranking-btn').onclick = () => void openRanking();
$('intro-ranking').onclick = () => void openRanking();
$('finder-ranking').onclick = () => void openRanking();
$('ranking-close').onclick = closeRanking;
if (edition) $('intro-ranking').hidden = true;

function renderResult(r: FinderResult): HTMLLIElement {
  const li = document.createElement('li');
  li.className = `result${r.sponsored ? ' is-sponsored' : ''}`;
  if (r.color) li.style.setProperty('--brand', r.color);
  li.innerHTML = `
    <button type="button" class="result-main">
      <span class="result-photo">${r.image ? '<img alt="" loading="lazy" />' : icon(r.kind === 'lugar' ? 'pin' : 'storefront')}</span>
      <span class="result-text"><b></b><small></small><span class="result-desc"></span></span>
    </button>
    <div class="result-actions"></div>`;
  if (r.image) li.querySelector('img')!.src = r.image;
  li.querySelector('b')!.textContent = r.name;
  li.querySelector('small')!.textContent = [r.sponsored ? 'Patrocinado' : r.kind === 'lugar' ? 'Lugar de interés' : '', formatDistance(distance(ufo, r))].filter(Boolean).join(' · ');
  li.querySelector('.result-desc')!.textContent = r.description ?? '';
  const poi: Poi = r.poi ?? { id: r.id, name: r.name, lat: r.lat, lng: r.lng, description: r.description, url: r.link };
  li.querySelector<HTMLButtonElement>('.result-main')!.onclick = () => (r.poi ? openSheet(r.poi) : travelTo(poi));
  const actions = li.querySelector('.result-actions')!;
  const link = (href: string, html: string, onClick?: () => void) => {
    const a = document.createElement('a');
    a.className = 'btn btn-secondary btn-sm';
    a.href = href;
    a.target = '_blank';
    a.rel = r.sponsored ? 'noopener sponsored' : 'noopener';
    a.innerHTML = html;
    if (onClick) a.onclick = onClick;
    actions.append(a);
  };
  if (r.link) link(r.link, `${r.cta ?? 'Web'} ${icon('external')}`, r.sponsored ? () => track('anuncio-clic', { anuncio: r.id, origen: 'buscador' }) : undefined);
  if (r.maps) link(r.maps, `${icon('pin')} Maps`, () => track('anuncio-mapa', { anuncio: r.id, origen: 'buscador' }));
  const go = document.createElement('button');
  go.type = 'button';
  go.className = 'btn btn-primary btn-sm';
  go.innerHTML = `${icon('travel')} Ir`;
  go.onclick = () => travelTo(poi);
  actions.append(go);
  return li;
}

// ---------- Ajustes y controles ----------
function closePopovers() {
  $('settings').hidden = true;
  $('help').hidden = true;
}
function closePanels() {
  closePopovers();
  closeDrawer();
  closeFinder();
  closeRanking();
  closeSheet();
}
function togglePopover(id: 'settings' | 'help') {
  const el = $(id);
  const open = el.hidden;
  closePopovers();
  el.hidden = !open;
}
$('settings-btn').onclick = (e) => { e.stopPropagation(); togglePopover('settings'); };
$('help-btn').onclick = (e) => { e.stopPropagation(); togglePopover('help'); };
document.addEventListener('pointerdown', (e) => {
  const t = e.target as Node;
  for (const id of ['settings', 'help']) {
    const el = $(id);
    if (!el.hidden && !el.contains(t) && !$(`${id}-btn`).contains(t)) el.hidden = true;
  }
});

function renderQuality() {
  document.querySelectorAll<HTMLButtonElement>('[data-quality]').forEach((b) => {
    b.setAttribute('aria-checked', String(b.dataset.quality === quality));
  });
}
document.querySelectorAll<HTMLButtonElement>('[data-quality]').forEach((b) => {
  b.onclick = () => {
    quality = b.dataset.quality as Quality;
    setQuality(world, quality);
    renderQuality();
  };
});
renderQuality();

const FOUND_KEY = 'flyfly:showFound';
function renderFoundVisibility() {
  document.querySelectorAll<HTMLButtonElement>('[data-found]').forEach((b) => {
    b.setAttribute('aria-checked', String(b.dataset.found === pois.foundVisibility));
  });
}
try {
  const saved = localStorage.getItem(FOUND_KEY) as FoundVisibility | null;
  if (saved === 'todos' || saved === 'cercanos' || saved === 'ninguno') pois.foundVisibility = saved;
} catch { /* sin almacenamiento */ }
document.querySelectorAll<HTMLButtonElement>('[data-found]').forEach((b) => {
  b.onclick = () => {
    pois.foundVisibility = b.dataset.found as FoundVisibility;
    try { localStorage.setItem(FOUND_KEY, pois.foundVisibility); } catch { /* sin almacenamiento */ }
    renderFoundVisibility();
    if (flying) updateHud();
  };
});
renderFoundVisibility();

$('reset-progress').onclick = () => {
  if (!confirm('¿Reiniciar los lugares descubiertos en esta ciudad?')) return;
  pois.resetProgress();
  gridCount = -1;
  closePopovers();
  updateHud();
  toast({ title: 'Progreso reiniciado', iconName: 'reset' });
};
$('consent-btn').hidden = !adsEnabled;
$('consent-btn').onclick = () => {
  closePopovers();
  if (!manageConsent()) toast({ title: 'No hay cookies que gestionar ahora mismo', iconName: 'cookie' });
};
const about = $<HTMLDialogElement>('about');
$('about-btn').onclick = () => { closePopovers(); about.showModal(); };
$('about-close').onclick = () => about.close();

const HELP_KEY = 'flyfly:helpSeen';
function showHelpOnce() {
  if (matchMedia('(pointer: coarse)').matches) return;
  try {
    if (localStorage.getItem(HELP_KEY)) return;
    localStorage.setItem(HELP_KEY, '1');
  } catch { /* sin almacenamiento */ }
  $('help').hidden = false;
  setTimeout(() => ($('help').hidden = true), 9000);
}

// ---------- Ciudad completada ----------
function formatDuration(ms: number) {
  const min = Math.max(1, Math.round(ms / 60000));
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60), m = min % 60;
  if (h < 48) return m ? `${h} h ${m} min` : `${h} h`;
  return `${Math.round(h / 24)} días`;
}

function showVictory() {
  if (!currentCity) return;
  track('ciudad-completada', { ciudad: currentCity.name });
  const { total } = pois.progress();
  const stats = cityStats();
  $('victory-title').textContent = currentCity.name;
  $('v-places').textContent = `${total} de ${total}`;
  $('v-time').textContent = stats.first && stats.completed ? formatDuration(stats.completed - stats.first) : '-';
  $('v-km').textContent = `${(stats.km ?? 0).toFixed(1).replace('.', ',')} km`;
  // Confeti: piezas con posición, color y retraso aleatorios (solo CSS; se borra al cerrar).
  const box = $('confetti');
  box.innerHTML = '';
  const colors = ['#e2602f', '#f0b43c', '#34b277', '#4aa8e8', '#ffffff'];
  for (let i = 0; i < 70; i++) {
    const piece = document.createElement('i');
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.background = colors[i % colors.length];
    piece.style.animationDelay = `${Math.random() * 1.6}s`;
    piece.style.animationDuration = `${2.6 + Math.random() * 2}s`;
    box.append(piece);
  }
  closePanels();
  paused = true;
  $('victory').hidden = false;
}

function closeVictory() {
  $('victory').hidden = true;
  $('confetti').innerHTML = '';
  paused = false;
}
$('v-close').onclick = closeVictory;
$('v-auto').onclick = () => { closeVictory(); startAutopilot(); };

$('v-share').onclick = async () => {
  const url = `${location.origin}${location.pathname}`;
  const text = `He completado mi exploración de ${currentCity?.name ?? 'una ciudad'} en FlyFly. ¿Te atreves a explorar la tuya?`;
  try {
    if (navigator.share) {
      await navigator.share({ title: 'FlyFly', text, url });
      return;
    }
    await navigator.clipboard.writeText(`${text} ${url}`);
    toast({ title: 'Enlace copiado: pégalo donde quieras', iconName: 'share' });
  } catch {
    // Se canceló el diálogo de compartir.
  }
};

// ---------- Exploración automática (ciudad completada) ----------
interface Autopilot { visited: Set<string>; target?: Poi; pauseUntil: number }
let auto: Autopilot | null = null;
const AUTO_ALTITUDE = 110; // metros sobre el suelo

function isCityComplete() {
  const { discovered, total } = pois.progress();
  return total > 0 && discovered === total;
}

function renderAutoButton() {
  const btn = $('auto-btn');
  btn.hidden = !flying || !isCityComplete();
  btn.setAttribute('aria-pressed', String(!!auto));
  btn.classList.toggle('is-active', !!auto);
  $('auto-label').textContent = auto ? 'Detener' : 'Exploración automática';
  $('auto-icon').innerHTML = icon(auto ? 'stop' : 'path');
}

async function startAutopilot() {
  const places = [...pois.pois.values()].filter((p) => pois.isDiscovered(p) && !p.sponsor);
  if (!places.length) return;
  const start = places[Math.floor(Math.random() * places.length)];
  await travelTo(start);
  auto = { visited: new Set([start.id]), pauseUntil: performance.now() + 2000 };
  renderAutoButton();
  toast({ title: 'Exploración automática activada', iconName: 'path' });
}

function stopAutopilot() {
  if (!auto) return;
  auto = null;
  renderAutoButton();
}
$('auto-btn').onclick = () => (auto ? stopAutopilot() : startAutopilot());

/** Mandos del piloto automático: va en línea recta al lugar más cercano aún no visitado en este recorrido. */
function autopilotControls(now: number): Controls {
  const idle: Controls = { forward: 0, turn: 0, strafe: 0, lift: 0 };
  if (!auto) return idle;
  const lift = Math.max(-1, Math.min(1, (AUTO_ALTITUDE - ufo.altitude) / 40));
  if (now < auto.pauseUntil) return { ...idle, lift };
  if (!auto.target) {
    let best: { poi: Poi; d: number } | undefined;
    for (const p of pois.pois.values()) {
      if (p.sponsor || !pois.isDiscovered(p) || auto.visited.has(p.id)) continue;
      const d = distance(ufo, p);
      if (!best || d < best.d) best = { poi: p, d };
    }
    if (!best) {
      stopAutopilot();
      toast({ title: 'Recorrido completo: has visitado todos los lugares', iconName: 'confetti' });
      return idle;
    }
    auto.target = best.poi;
  }
  const target = auto.target;
  const d = distance(ufo, target);
  if (d < 40) {
    auto.visited.add(target.id);
    auto.target = undefined;
    auto.pauseUntil = now + 2500;
    toast({ label: 'De paso por', title: target.name, image: target.thumb });
    return { ...idle, lift };
  }
  const diff = ((((bearing(ufo, target) - (ufo.heading * 180) / Math.PI) % 360) + 540) % 360) - 180;
  const turn = Math.max(-1, Math.min(1, diff / 45));
  const forward = Math.abs(diff) > 50 ? 0.15 : d > 400 ? 1 : Math.max(0.35, d / 400);
  return { forward, turn, strafe: 0, lift };
}

// ---------- Mandos ----------
const keys = new Set<string>();
const MOVE_KEYS = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyR', 'KeyF', 'Space', 'ShiftLeft', 'ShiftRight', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
const stick = { x: 0, y: 0 };
let touchLift = 0;

window.addEventListener('keydown', (e) => {
  if (e.target instanceof HTMLInputElement || about.open) return;
  keys.add(e.code);
  if (MOVE_KEYS.includes(e.code)) stopAutopilot();
  if (e.code === 'KeyC') ufo.toggleCamera();
  // if (e.code === 'KeyM') sound.toggle(); // Sonido
  if (e.code === 'Escape') { closePanels(); if (!$('victory').hidden) closeVictory(); }
  if (e.code === 'Tab' && flying) { e.preventDefault(); toggleDrawer(); }
  if (e.code.startsWith('Arrow') || e.code === 'Space') e.preventDefault();
});
window.addEventListener('keyup', (e) => keys.delete(e.code));
window.addEventListener('blur', () => keys.clear());

const axis = (neg: string[], pos: string[]) =>
  (pos.some((k) => keys.has(k)) ? 1 : 0) - (neg.some((k) => keys.has(k)) ? 1 : 0);

function readControls(): Controls {
  return {
    forward: axis(['ArrowDown', 'KeyS'], ['ArrowUp', 'KeyW']) - stick.y,
    turn: axis(['ArrowLeft'], ['ArrowRight']) + stick.x,
    strafe: axis(['KeyA'], ['KeyD']),
    lift: axis(['ShiftLeft', 'ShiftRight', 'KeyF'], ['Space', 'KeyR']) + touchLift,
  };
}

// Joystick táctil: arriba/abajo avanza o retrocede, a los lados gira.
const stickEl = $('stick');
const knob = stickEl.firstElementChild as HTMLElement;
stickEl.addEventListener('pointerdown', (e) => {
  stickEl.setPointerCapture(e.pointerId);
  stopAutopilot();
});
stickEl.addEventListener('pointermove', (e) => {
  if (!stickEl.hasPointerCapture(e.pointerId)) return;
  const r = stickEl.getBoundingClientRect();
  const clamp = (v: number) => Math.max(-1, Math.min(1, v));
  stick.x = clamp((e.clientX - r.left - r.width / 2) / (r.width / 2));
  stick.y = clamp((e.clientY - r.top - r.height / 2) / (r.height / 2));
  knob.style.transform = `translate(${stick.x * 40}px, ${stick.y * 40}px)`;
});
const releaseStick = () => { stick.x = stick.y = 0; knob.style.transform = ''; };
stickEl.addEventListener('pointerup', releaseStick);
stickEl.addEventListener('pointercancel', releaseStick);
document.querySelectorAll<HTMLButtonElement>('[data-lift]').forEach((b) => {
  b.onpointerdown = () => {
    stopAutopilot();
    touchLift = Number(b.dataset.lift);
  };
  b.onpointerup = b.onpointerleave = b.onpointercancel = () => (touchLift = 0);
});
$('cam-btn').onclick = () => ufo.toggleCamera();

// Cámara: arrastrar (ratón o un dedo) gira 360°, rueda o pellizco acerca/aleja.
const canvas = viewer.scene.canvas;
const pointers = new Map<number, { x: number; y: number }>();
const pinchDistance = () => {
  const [a, b] = [...pointers.values()];
  return Math.hypot(a.x - b.x, a.y - b.y);
};
canvas.addEventListener('pointerdown', (e) => {
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  canvas.setPointerCapture(e.pointerId);
  closePopovers();
});
canvas.addEventListener('pointermove', (e) => {
  const prev = pointers.get(e.pointerId);
  if (!prev) return;
  if (pointers.size === 1) {
    ufo.orbit(e.clientX - prev.x, e.clientY - prev.y);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  } else if (pointers.size === 2) {
    const before = pinchDistance();
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    ufo.zoom(before / Math.max(1, pinchDistance()));
  }
});
const releasePointer = (e: PointerEvent) => pointers.delete(e.pointerId);
canvas.addEventListener('pointerup', releasePointer);
canvas.addEventListener('pointercancel', releasePointer);
canvas.addEventListener('wheel', (e) => {
  e.preventDefault();
  ufo.zoom(Math.exp(e.deltaY * 0.001));
}, { passive: false });

// ---------- HUD ----------
function updateHud() {
  const { found, target } = pois.update(ufo.lat, ufo.lng, ufo.ground, ufo.excluded);
  const { discovered, total } = pois.progress();
  if (found) {
    // sound.chime(); // Sonido
    gridCount = -1;
    if (!cityStats().first) saveCityStats({ first: Date.now() });
    if (discovered === total && total > 0) {
      saveCityStats({ completed: Date.now(), km: (cityStats().km ?? 0) + pendingKm });
      pendingKm = 0;
      showVictory();
    } else {
      toast({ label: 'Descubierto', title: found.name, image: found.thumb });
      openSheet(found, true);
    }
  }
  renderAutoButton();
  $('visited').textContent = String(discovered);
  $('total').textContent = String(total);

  // Brújula hacia el lugar oculto más cercano (la flecha del icono apunta al noroeste: +45°).
  $('compass').hidden = !target;
  if (target) {
    $('compass-dist').textContent = formatDistance(target.dist);
    const rel = bearing(ufo, target.poi) - (ufo.heading * 180) / Math.PI;
    $('compass-arrow').style.transform = `rotate(${(rel + 45).toFixed(1)}deg)`;
  }

  // Altitud sobre el nivel del mar: las teselas 3D usan alturas elipsoidales (WGS84), se corrige con el geoide.
  const msl = world.tileset ? ufo.height - geoidHeight(ufo.lat, ufo.lng) : ufo.height;
  $('altitude-value').textContent = `${Math.round(msl)} m`;

  if (openPoi) {
    const d = distance(ufo, openPoi);
    $('sheet-dist').textContent = `A ${formatDistance(d)}`;
    if (sheetFromDiscovery && d > 900) closeSheet();
  }
  if (!$('drawer').hidden) renderDrawer();
}

// ---------- Bucle principal ----------
let last = performance.now();
let slowTimer = 0;
let pendingKm = 0;
let kmSaveTimer = 0;

/** Suma la distancia recorrida en la ciudad (los saltos de teletransporte no cuentan). */
function trackDistance(dt: number) {
  if (lastPos) {
    const d = distance(lastPos, ufo);
    if (d < 500) pendingKm += d / 1000;
  }
  lastPos = { lat: ufo.lat, lng: ufo.lng };
  kmSaveTimer += dt;
  if (kmSaveTimer > 5 && pendingKm > 0) {
    saveCityStats({ km: (cityStats().km ?? 0) + pendingKm });
    pendingKm = 0;
    kmSaveTimer = 0;
  }
}

viewer.scene.preUpdate.addEventListener(() => {
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.1);
  last = now;
  if (paused) return;
  const manual = readControls();
  // Cualquier mando manual desactiva el piloto automático.
  if (auto && (manual.forward || manual.turn || manual.strafe || manual.lift)) stopAutopilot();
  ufo.update(dt, auto ? autopilotControls(now) : manual);
  ufo.render(dt);
  // sound.update(ufo.speed); // Sonido

  slowTimer += dt;
  if (slowTimer > 0.25) {
    slowTimer = 0;
    ufo.sampleGround([...pois.excluded, ...ads.excluded]);
    trackDistance(0.25);
    updateHud();
  }
});
// Los marcadores HTML se recolocan después de cada fotograma, con la cámara ya actualizada.
let lastRender = performance.now();
viewer.scene.postRender.addEventListener(() => {
  const now = performance.now();
  pois.render();
  ads.render(Math.min((now - lastRender) / 1000, 0.1));
  lastRender = now;
});

// Acceso para depuración en desarrollo (no se incluye en la web publicada).
if (import.meta.env.DEV) Object.assign(window, { flyfly: { ufo, pois, ads, intro, goHome, startFlight, openSheet, travelTo, showVictory, startAutopilot } });
